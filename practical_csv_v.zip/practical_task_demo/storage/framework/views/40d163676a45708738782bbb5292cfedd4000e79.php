<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Call Details Data</title>
</head>

<body>
    <form action="/import-csv" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p>Upload Csv File</p>
        <input type="file" name="file">
        <br>
        <br>
        <button type="submit">Upload CSV File</button>
    </form>
    <hr>

    <form action="/search" method="GET">
        <?php echo csrf_field(); ?>
        <br>
        <table>
            <tr>
                <td> <label>Direction</label>
                    <input type="text" name="direction">
                </td>
                <td> <label>Leg</label>
                    <input type="text" name="leg">
                </td>
                <td>
                    <label>CID Name </label>
                    <input type="text" name="caller_id_name">
                </td>
                <td> <label>CID Number</label>
                    <input type="text" name="caller_id_number">
                </td>
            </tr>

            <tr>
                <td>
                    <label>Designation</label>
                    <input type="text" name="designation">
                </td>
                <td>
                    <label>UUID</label>
                    <input type="text" name="uuid">
                </td>
                <td> <label>Bridge UUID</label>
                    <input type="text" name="bridge_uuid">
                </td>
            </tr>
        </table>
        <button type="submit" center>Search</button>
    </form>
    <br>
    <br>
    <table border="2">
        <tr>
            <th>Direction</th>
            <th>Leg</th>
            <th>UUID</th>
            <th>Bridge UUID</th>
        </tr>
        <?php if(!empty($callDetailData)): ?>
        <?php $__currentLoopData = $callDetailData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($cd->direction); ?></td>
            <td><?php echo e($cd->leg); ?></td>
            <td><?php echo e($cd->uuid); ?></td>
            <td><?php echo e($cd->bridge_uuid); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>


    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>

</body>

</html><?php /**PATH C:\xampp7.3\practical_task_demo\resources\views/index.blade.php ENDPATH**/ ?>