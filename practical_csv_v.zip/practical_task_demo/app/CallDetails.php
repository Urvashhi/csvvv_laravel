<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CallDetails extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'domain_uuid',
        'start_stamp',
        'start_epoch',
        'hangup_cause',
        'duration',
        'billmsec',
        'record_path',
        'record_name',
        'uuid',
        'bridge_uuid',
        'direction',
        'billsec',
        'caller_id_name',
        'caller_id_number',
        'caller_destination',
        'source_number',
        'destination_number',
        'leg',
        'raw_data_exists',
        'account_code',
        'answer_stamp',
        'sip_hangup_disposition',
        'pdd_ms',
        'rtp_audio_in_mos',
        'tta'
    ];

    protected $table = 'call_detals';
}
