<?php

namespace App\Http\Controllers;

use App\CallDetails;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;

class CallDetailController extends Controller
{
    //redirect to index file
    public function index()
    {
        return view('index');
    }

    //import csv data
    public function importCSV(Request $request)
    {
        $file = $request->file('file');
        $filePath = $file->getRealPath();
        $csvData = array_map('str_getcsv', file($filePath));
        array_shift($csvData);
        if ($file) {
            foreach ($csvData as $data) {
                $this->storeData($data);
            }
            Session::flash('success', 'CSV data imported successfuly');
            return redirect()->back();
        }
    }

    //store data of call detail
    public function storeData($data)
    {
        $insertData = array(
            'domain_uuid' => $data[0] ?? null,
            // 'start_stamp' => Carbon::createFromFormat('d-m-Y H:i', $data[1])
            //     ->format('Y-m-d H:i')
            //     ?? null,
            'start_epoch' => $data[1] ?? null,
            'start_epoch' => $data[2] ?? null,
            'hangup_cause' => $data[3] ?? null,
            'duration' => $data[4],
            'billmsec' => $data[5],
            'record_path' => $data[6],
            'record_name' => $data[7],
            'uuid' => $data[8],
            'bridge_uuid' => $data[9],
            'direction' => $data[10],
            'billsec' => $data[11],
            'caller_id_name' => $data[12],
            'caller_id_number' => $data[13],
            'caller_destination' => $data[14],
            'source_number' => $data[15] ?? null,
            'destination_number' => $data[16],
            'leg' => $data[17],
            'raw_data_exists' => $data[18],
            'account_code' => $data[19] ?? null,
            'answer_stamp' => null,
            'sip_hangup_disposition' => $data[21],
            'pdd_ms' => $data[22],
            'rtp_audio_in_mos' => $data[23] ?? null,
            'tta' => $data[24]

        );
        CallDetails::create($insertData);
    }

    //search for csv data
    public function search(Request $request)
    {

        $request->validate([
            'field_name' => 'string|nullable',
            'leg' => 'string|nullable',
        ]);

        $callDetail = CallDetails::query();
        $callDetail = $this->subSearch($request, $callDetail);

        // $query = CallDetails::get();
        $callDetailData = $callDetail->paginate(10);

        if ($request->is('api/*')) {

            if (empty($callDetailData)) {
                return response()->json(['message' => 'No data found']);
            }
            return response()->json($callDetailData);
        }
        return view('index', compact('callDetailData'));
    }

    //sub search function
    public function subSearch($request, $callDetail)
    {
        if ($request->has('direction') && !empty($request->direction)) {
            $callDetail->where('direction', 'LIKE', '%' . $request->get('direction') .
                '%');
        }

        if ($request->has('leg') && !empty($request->leg)) {
            $callDetail->where('leg', $request->leg);
        }
        if ($request->has('caller_id_name') && !empty($request->leg)) {
            $callDetail->where('caller_id_name', 'LIKE', '%' . $request->caller_id_name . '%');
        }
        if ($request->has('caller_id_number')  && !empty($request->leg)) {
            $callDetail->where('caller_id_number', $request->caller_id_number);
        }

        if ($request->has('destination_number') && !empty($request->leg)) {
            $callDetail->where('destination_number', $request->destination_number);
        }

        if ($request->has('duration') && !empty($request->duration)) {
            $callDetail->where('duration', $request->duration);
        }

        if ($request->has('answer_stamp') && !empty($request->answer_stamp)) {
            $callDetail->where('answer_stamp', $request->answer_stamp);
        }

        if ($request->has('start_stamp') && !empty($request->start_stamp)) {
            $callDetail->where('start_stamp', $request->start_stamp);
        }

        if ($request->has('billmsec') && !empty($request->billmsec)) {
            $callDetail->where('uuid', $request->billmsec);
        }

        if ($request->has('bridge_uuid') && !empty($request->bridge_uuid)) {
            $callDetail->where('bridge_uuid', $request->bridge_uuid);
        }
        return $callDetail;
    }
}
