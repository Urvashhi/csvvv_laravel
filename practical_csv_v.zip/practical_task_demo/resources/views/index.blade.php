<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Call Details Data</title>
</head>

<body>
    <form action="/import-csv" method="POST" enctype="multipart/form-data">
        @csrf
        <p>Upload Csv File</p>
        <input type="file" name="file">
        <br>
        <br>
        <button type="submit">Upload CSV File</button>
    </form>
    <hr>

    <form action="/search" method="GET">
        @csrf
        <br>
        <table>
            <tr>
                <td> <label>Direction</label>
                    <input type="text" name="direction">
                </td>
                <td> <label>Leg</label>
                    <input type="text" name="leg">
                </td>
                <td>
                    <label>CID Name </label>
                    <input type="text" name="caller_id_name">
                </td>
                <td> <label>CID Number</label>
                    <input type="text" name="caller_id_number">
                </td>
            </tr>

            <tr>
                <td>
                    <label>Designation</label>
                    <input type="text" name="designation">
                </td>
                <td>
                    <label>UUID</label>
                    <input type="text" name="uuid">
                </td>
                <td> <label>Bridge UUID</label>
                    <input type="text" name="bridge_uuid">
                </td>
            </tr>
        </table>
        <button type="submit" center>Search</button>
    </form>
    <br>
    <br>
    <table border="2">
        <tr>
            <th>Direction</th>
            <th>Leg</th>
            <th>UUID</th>
            <th>Bridge UUID</th>
        </tr>
        @if(!empty($callDetailData))
        @foreach($callDetailData as $cd)
        <tr>
            <td> {{ $cd->direction }}</td>
            <td>{{ $cd->leg }}</td>
            <td>{{ $cd->uuid }}</td>
            <td>{{ $cd->bridge_uuid }}</td>
        </tr>
        @endforeach
        @endif
    </table>


    @if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
    @endif

</body>

</html>