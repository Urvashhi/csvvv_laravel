//Funtionality 
    -import CSV file
    -Store data in DB
    -Search that data
    -View data

//Installation of project 
1) composer create-project --prefer-dist laravel/laravel practical_task_demo "7.*" 

2) Changes in env

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=call_details_csv_changes
DB_USERNAME=root
DB_PASSWORD=

//Make Model,Controller,migratiion
1) php artisan make:model

2)php artisan make:controoller

3)php artisan make:migration 


