<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCallDetalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('call_detals', function (Blueprint $table) {
            $table->id();
            $table->string('domain_uuid');
            $table->timestamp('start_stamp');
            $table->string('start_epoch');
            $table->string('hangup_cause');
            $table->string('duration');
            $table->string('billmsec');
            $table->string('record_path');
            $table->string('record_name');
            $table->string('uuid');
            $table->string('bridge_uuid');
            $table->string('direction');
            $table->string('billsec');
            $table->string('caller_id_name');
            $table->string('caller_id_number');
            $table->string('caller_destination');
            $table->string('source_number')->nullable();
            $table->string('destination_number');
            $table->string('leg');
            $table->string('raw_data_exists');
            $table->string('account_code')->nullable();
            $table->timestamp('answer_stamp')->nullable();
            $table->string('sip_hangup_disposition');
            $table->string('pdd_ms');
            $table->string('rtp_audio_in_mos')->nullable();
            $table->string('tta');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('call_detals');
    }
}
